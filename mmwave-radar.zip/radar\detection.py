# -*- coding: utf-8 -*-
"""检测层：有无人判断（去抖动）+ 位置汇总输出。"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import List

from .signal import DetectionResult, Target


@dataclass
class PresenceTracker:
    """有无人状态机，避免单帧虚警/漏检抖动。

    - 连续 `confirm` 帧检测到运动目标 → 判定「有人」
    - 连续 `release` 帧无目标 → 判定「无人」
    """
    confirm: int = 2
    release: int = 5
    _hit: int = 0
    _miss: int = 0
    present: bool = False

    def update(self, has_target: bool) -> bool:
        if has_target:
            self._hit += 1
            self._miss = 0
        else:
            self._miss += 1
            self._hit = 0

        if not self.present and self._hit >= self.confirm:
            self.present = True
        elif self.present and self._miss >= self.release:
            self.present = False
        return self.present


def summarize(result: DetectionResult, present: bool) -> str:
    """把一帧检测结果格式化成一行文本。"""
    parts = [f"帧 {result.frame_no:>4}"]
    parts.append(f"有人" if present else f"无人")
    if result.targets:
        t = max(result.targets, key=lambda x: x.energy)
        parts.append(
            f"目标: 距离 {t.distance_m:.2f}m  "
            f"角度 {t.angle_deg:+5.1f}°  "
            f"速度 {t.velocity_mps:+.2f}m/s  "
            f"信噪比 {t.energy:.1f}×"
        )
    else:
        parts.append("无目标")
    return " | ".join(parts)


def describe_target(t: Target) -> str:
    return (f"  bin{t.range_bin} 距离 {t.distance_m:.2f}m  "
            f"角度 {t.angle_deg:+5.1f}°  速度 {t.velocity_mps:+.2f}m/s  "
            f"信噪比 {t.energy:.1f}×")
