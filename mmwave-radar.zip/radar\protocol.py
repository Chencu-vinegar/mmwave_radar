# -*- coding: utf-8 -*-
"""加特兰 ICL1122 数据记录解析。

记录结构（从 RadarData_1.dat 逆向得出，详见 docs/radar-data-format.md）：

数据记录 52 字节：
    +0  'ICLH'                 4 字节同步头
    +4  uint16 length = 40      数据长度
    +6  uint16 flag             0x0000=Rx0 / 0x0100=Rx1
    +8  uint16[20]              40 字节数据区
        [0]  0xAA??            同步字节 0xAA 在低字节
        [1]  chirp 计数器      高字节恒 0x09，低字节 0x10 步进 16 值循环
        [2..17] 8 个复数 bin   I/Q 交错：(I0,Q0)...(I7,Q7)
        [18] 状态字
        [19] ??0x55            同步字节 0x55 在高字节
    +48 'ICLT'                 4 字节同步尾

边界记录 16 字节：
    +0  'ICLH'
    +4  uint16 length = 4
    +6  uint16 flag = 0x0080
    +8  uint32 帧序号
    +12 'ICLT'
"""
from __future__ import annotations

import struct
from dataclasses import dataclass, field
from typing import List, Optional

HEAD = b"ICLH"
TAIL = b"ICLT"
DATA_LEN = 40
BOUNDARY_LEN = 4
DATA_REC_SIZE = 52          # 4 + 2 + 2 + 40 + 4
BOUNDARY_REC_SIZE = 16      # 4 + 2 + 2 + 4 + 4

SYNC_AA = 0xAA
SYNC_55 = 0x55


@dataclass
class DataRecord:
    flag: int = 0                # 0x0000 或 0x0100
    counter: int = 0             # chirp 计数器 int16[1]
    bins: List[complex] = field(default_factory=list)  # 8 个复数 bin
    status: int = 0
    rx_index: int = 0            # 0 或 1（由 flag 推导）

    @property
    def magnitudes(self) -> List[float]:
        return [abs(b) for b in self.bins]


@dataclass
class BoundaryRecord:
    flag: int = 0
    frame_no: int = 0


class ProtocolError(Exception):
    pass


def parse_data_record(payload: bytes) -> DataRecord:
    """解析 40 字节数据区，返回 DataRecord。"""
    if len(payload) != DATA_LEN:
        raise ProtocolError(f"数据区长度错误: {len(payload)}")

    vals = struct.unpack_from("<20h", payload, 0)
    # 同步校验
    if (vals[0] & 0xFF) != SYNC_AA:
        raise ProtocolError(f"同步字节 0xAA 缺失: {vals[0] & 0xFF:04x}")
    if (vals[19] >> 8) != SYNC_55:
        raise ProtocolError(f"同步字节 0x55 缺失: {vals[19] >> 8:04x}")

    counter = vals[1]
    # 16 个 FFT 值 = 8 复数 bin，I/Q 交错
    raw = vals[2:18]
    bins = [complex(raw[2 * k], raw[2 * k + 1]) for k in range(8)]

    return DataRecord(
        flag=0,  # 由外层填充
        counter=counter,
        bins=bins,
        status=vals[18],
        rx_index=0,
    )


def decode_flag_rx(flag: int) -> int:
    """由 flag 推导 Rx 索引：0x0000→Rx0, 0x0100→Rx1。"""
    return 0 if flag == 0x0000 else (1 if flag == 0x0100 else -1)


class StreamParser:
    """流式解析器：喂入字节，产出 DataRecord（边界记录单独记录）。

    用于实时串口，自动在字节流中寻找 ICLH 同步头并切分记录。
    内部状态机区分三种结果：数据不足 / 数据记录 / 边界记录，
    保证遇到边界记录或假头后仍继续解析后续记录。
    """

    _NEED = 0        # 数据不足，停止本轮
    _DATA = 1        # 解析出数据记录
    _SKIP = 2        # 解析了边界记录或跳过假头，继续循环

    def __init__(self) -> None:
        self._buf = bytearray()
        self._last_boundary: Optional[BoundaryRecord] = None
        self._last_record: Optional[DataRecord] = None

    def feed(self, data: bytes) -> List[DataRecord]:
        """喂入原始字节，返回解析出的数据记录列表。"""
        self._buf += data
        records: List[DataRecord] = []
        while True:
            status = self._parse_next()
            if status == self._NEED:
                break
            if status == self._DATA and self._last_record is not None:
                records.append(self._last_record)
            # _SKIP（边界/假头）：继续循环
        return records

    def _parse_next(self) -> int:
        b = self._buf
        idx = b.find(HEAD)
        if idx < 0:
            # 保留尾部最多 3 字节（可能是半个 ICLH）
            if len(b) > 3:
                del b[:-3]
            return self._NEED
        if idx > 0:
            del b[:idx]          # 丢弃同步头前的垃圾字节

        if len(b) < 8:              # 需要读到 flag（offset 6-7）
            return self._NEED
        ln = struct.unpack_from("<H", b, 4)[0]
        flag = struct.unpack_from("<H", b, 6)[0]

        if ln == DATA_LEN:
            if len(b) < DATA_REC_SIZE:
                return self._NEED
            payload = bytes(b[8:8 + DATA_LEN])
            if b[8 + DATA_LEN:12 + DATA_LEN] != TAIL:
                del b[:4]        # 尾部不对，跳过这个假头
                return self._SKIP
            del b[:DATA_REC_SIZE]
            rec = parse_data_record(payload)
            rec.flag = flag
            rec.rx_index = decode_flag_rx(flag)
            self._last_record = rec
            return self._DATA
        elif ln == BOUNDARY_LEN:
            if len(b) < BOUNDARY_REC_SIZE:
                return self._NEED
            if b[12:16] != TAIL:
                del b[:4]
                return self._SKIP
            frame_no = struct.unpack_from("<I", b, 8)[0]
            del b[:BOUNDARY_REC_SIZE]
            self._last_boundary = BoundaryRecord(flag=flag, frame_no=frame_no)
            return self._SKIP
        else:
            # 未知长度，跳过此头
            del b[:4]
            return self._SKIP

    @property
    def last_boundary(self) -> Optional[BoundaryRecord]:
        return self._last_boundary


def parse_file(path: str) -> List[DataRecord]:
    """离线解析整个 .dat 文件，返回全部数据记录。"""
    with open(path, "rb") as f:
        data = f.read()
    parser = StreamParser()
    return parser.feed(data)
