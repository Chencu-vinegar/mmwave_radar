# -*- coding: utf-8 -*-
"""毫米波雷达（加特兰 ICL1122 / DEV202H）有无人检测 + 位置程序入口。

用法：
  实时串口（默认）:  python main.py
                     python main.py --serial COM5
  离线回放:          python main.py --file RadarData_1.dat
                     python main.py --file RadarData_1.dat --fast   # 最快速度回放

输出：每帧一行「帧号 | 有人/无人 | 目标距离/角度/速度/能量」。
"""
from __future__ import annotations

import argparse
import os
import sys
import time

try:
    sys.stdout.reconfigure(encoding="utf-8")
    sys.stderr.reconfigure(encoding="utf-8")
except Exception:
    pass
if os.name == "nt":
    try:
        import ctypes
        ctypes.windll.kernel32.SetConsoleOutputCP(65001)
    except Exception:
        pass

from config import RadarConfig
from radar import StreamParser, FrameAssembler, Processor
from radar.detection import PresenceTracker, summarize, describe_target


def make_processor(cfg: RadarConfig) -> Processor:
    return Processor(cfg)


def run_file(cfg: RadarConfig, path: str, fast: bool) -> None:
    """离线回放 .dat 文件。"""
    print(f"[离线回放] {path}")
    parser = StreamParser()
    assembler = FrameAssembler()
    proc = make_processor(cfg)
    tracker = PresenceTracker()

    frame_interval = 129500e-6  # 帧时间（秒），用于实时速率回放
    with open(path, "rb") as f:
        data = f.read()

    records = parser.feed(data)
    print(f"[解析] 共 {len(records)} 条数据记录")
    if parser.last_boundary:
        print(f"[帧边界] 帧序号 {parser.last_boundary.frame_no}")

    frames = assembler.feed(records)
    print(f"[组装] 共 {len(frames)} 帧\n")

    t0 = time.time()
    frame_idx = 0
    for frame in frames:
        result = proc.process(frame)
        present = tracker.update(result.presence)
        line = summarize(result, present)
        print(line)
        if result.targets and cfg.verbose:
            for t in result.targets:
                print(describe_target(t))
        frame_idx += 1
        if not fast:
            # 按实时帧率回放
            elapsed = time.time() - t0
            target_t = frame_idx * frame_interval
            if elapsed < target_t:
                time.sleep(target_t - elapsed)

    print(f"\n[完成] 处理 {len(frames)} 帧")


def list_serial_ports() -> List[str]:
    """列出可用串口（排除蓝牙虚拟串口 BTHENUM）。"""
    import serial.tools.list_ports as lp
    return [p.device for p in lp.comports() if "BTHENUM" not in (p.hwid or "")]


def run_serial(cfg: RadarConfig, port: str) -> None:
    """实时串口读取（counter 回绕做帧对齐）。"""
    import serial

    print(f"[实时串口] {port} @ {cfg.baudrate} 波特")
    try:
        ser = serial.Serial(port, cfg.baudrate, timeout=cfg.timeout)
    except (serial.SerialException, Exception) as e:
        avail = list_serial_ports()
        print(f"[错误] 无法打开 {port}: {e}")
        if avail:
            print(f"当前可用串口: {', '.join(avail)}")
        else:
            print("未检测到可用串口（请检查雷达是否已连接并安装驱动）。")
        return

    parser = StreamParser()
    assembler = FrameAssembler(align=True)
    proc = make_processor(cfg)
    tracker = PresenceTracker()

    print("开始读取（Ctrl+C 退出）...\n")
    try:
        while True:
            n = ser.in_waiting or 1
            data = ser.read(n)
            if not data:
                continue
            records = parser.feed(data)
            if not records:
                continue
            for frame in assembler.feed(records):
                result = proc.process(frame)
                present = tracker.update(result.presence)
                print(summarize(result, present))
                if result.targets and cfg.verbose:
                    for t in result.targets:
                        print(describe_target(t))
    except KeyboardInterrupt:
        print("\n[停止] 用户中断")
    finally:
        ser.close()


def main() -> None:
    ap = argparse.ArgumentParser(description="毫米波雷达有无人检测")
    ap.add_argument("--file", help="离线 .dat 文件路径（回放模式）")
    ap.add_argument("--serial", help="串口名（默认 COM5）")
    ap.add_argument("--fast", action="store_true", help="文件回放用最快速度")
    ap.add_argument("--no-angle", action="store_true", help="关闭角度估计")
    ap.add_argument("--no-mti", action="store_true", help="关闭 MTI 静止对消")
    args = ap.parse_args()

    cfg = RadarConfig()
    if args.no_angle:
        cfg.angle_enable = False
    if args.no_mti:
        cfg.mti_enable = False

    if args.file:
        run_file(cfg, args.file, args.fast)
    else:
        port = args.serial
        if not port:
            # 未显式指定：优先用配置默认 COM5；不存在则自动扫描非蓝牙串口
            import serial
            try:
                serial.Serial(cfg.port, baudrate=1).close()
                port = cfg.port
            except Exception:
                avail = list_serial_ports()
                if avail:
                    port = avail[0]
                    print(f"[提示] 默认端口 {cfg.port} 不存在，自动选择 {port}")
                else:
                    port = cfg.port
        run_serial(cfg, port)


if __name__ == "__main__":
    main()
