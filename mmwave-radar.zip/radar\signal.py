# -*- coding: utf-8 -*-
"""信号处理：帧组装 → 距离谱背景减除 → 能量检测 → 角度/速度估计。

数据流：64 条 DataRecord = 1 帧 = 32 chirp × 2 Rx。
重组为 Rx0 / Rx1 各 (32 chirp × 8 距离 bin) 复数矩阵。

检测策略（针对「固定杂波 + 运动目标」的室内有无人场景）：
    1. 每帧计算「距离谱」：每个 bin 在 32 个 chirp 上的幅度均值。
    2. 滑动平均建立背景距离谱（慢速适应增益漂移）。
    3. 当前 bin 能量 > 背景 × detect_mult 判为目标（背景减除）。
    4. 目标距离 = bin × 距离分辨率；角度 = 两 Rx 相位差；速度 = 多普勒峰。
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field
from typing import List, Optional

from .fftlib import fft
from .protocol import DataRecord


@dataclass
class Frame:
    """一帧重组后的数据。"""
    frame_no: int = 0
    rx0: List[List[complex]] = field(default_factory=list)  # (chirp × bin)
    rx1: List[List[complex]] = field(default_factory=list)


@dataclass
class Target:
    """检测到的目标。"""
    range_bin: int = 0
    velocity_bin: int = 0
    distance_m: float = 0.0
    velocity_mps: float = 0.0
    angle_deg: float = 0.0
    energy: float = 0.0


@dataclass
class DetectionResult:
    """单帧检测结果。"""
    frame_no: int = 0
    targets: List[Target] = field(default_factory=list)
    noise_floor: float = 0.0          # 背景距离谱最小值（诊断用）
    peak_energy: float = 0.0
    presence: bool = False            # 是否有人（存在目标）

    @property
    def person_count(self) -> int:
        return len(self.targets)


class FrameAssembler:
    """把数据记录流组装成帧。

    一帧 = 64 条记录（32 chirp × 2 Rx），counter 16 值循环（0x0900→0x09F0），
    一帧正好覆盖 2 个完整 counter 循环，故 counter 从 0x09F0 回绕到 0x0900
    标志新帧起点。

    align=True（实时串口）：从任意字节流进入，先丢弃对齐前的数据，等
    counter 回绕点（0x09F0→0x0900）作为帧起点，再固定 64 条切帧。
    align=False（离线文件）：文件首条即帧起点（已验证），直接切帧。
    """

    def __init__(self, records_per_frame: int = 64, align: bool = False) -> None:
        self.rpf = records_per_frame
        self.align = align
        self._buf: List[DataRecord] = []
        self._frame_no = 0
        self._aligned = not align
        self._prev_counter: Optional[int] = None

    def feed(self, records: List[DataRecord]) -> List[Frame]:
        frames: List[Frame] = []
        for rec in records:
            if not self._aligned:
                # 检测 counter 回绕（0x09F0 → 0x0900），标志新帧起点
                if self._prev_counter is not None and rec.counter < self._prev_counter:
                    self._aligned = True
                    self._buf = [rec]
                    self._prev_counter = rec.counter
                    continue
                self._prev_counter = rec.counter
                continue
            self._buf.append(rec)
            if len(self._buf) >= self.rpf:
                frames.append(self._build())
        return frames

    def _build(self) -> Frame:
        recs = self._buf[:self.rpf]
        self._buf = self._buf[self.rpf:]
        rx0 = [r.bins for r in recs if r.rx_index == 0][:32]
        rx1 = [r.bins for r in recs if r.rx_index == 1][:32]
        self._frame_no += 1
        return Frame(frame_no=self._frame_no, rx0=rx0, rx1=rx1)


class Processor:
    """每帧信号处理：距离谱背景减除 + 能量检测 + 角度/速度估计。"""

    def __init__(self, config) -> None:
        self.cfg = config
        self.n_vel = config.velocity_fft_size           # 速度维 FFT 尺寸（64）
        self.n_chirp = config.velocity_chirps           # 有效 chirp 数（32）
        self.bg_profile: Optional[List[float]] = None   # 背景距离谱
        self._frame_count = 0
        self._setup_velocity()

    def _setup_velocity(self) -> None:
        # chirp 周期 = 帧时间 / chirp 数
        frame_time = getattr(self.cfg, "frame_time_us", 129500.0) * 1e-6
        t_c = frame_time / self.cfg.chirps_per_frame
        lam = self.cfg.wavelength_m
        self.v_max = lam / (4.0 * t_c)                  # 最大无模糊速度
        self.dv = 2.0 * self.v_max / self.n_vel         # 速度 bin 分辨率

    def process(self, frame: Frame) -> DetectionResult:
        res = DetectionResult(frame_no=frame.frame_no)
        rx0 = frame.rx0
        rx1 = frame.rx1
        if len(rx0) < 2:
            return res

        n_chirp = len(rx0)
        n_bin = len(rx0[0])

        # 1. 距离谱：每 bin 在 chirp 维的幅度均值（Rx0）
        profile = []
        for b in range(n_bin):
            amps = [abs(rx0[c][b]) for c in range(n_chirp)]
            profile.append(sum(amps) / len(amps))

        # 增益归一化：除以本帧均值，消除乘性增益漂移（帧能量 10 倍波动）
        mean_p = sum(profile) / len(profile)
        if mean_p > 0:
            profile = [p / mean_p for p in profile]

        # 2. 背景更新（滑动平均，慢速适应增益漂移）
        self._frame_count += 1
        if self.bg_profile is None:
            self.bg_profile = list(profile)
        else:
            a = self.cfg.bg_alpha
            self.bg_profile = [a * bg + (1.0 - a) * p
                               for bg, p in zip(self.bg_profile, profile)]

        # 预热期：前 N 帧只建背景不检测
        if self._frame_count <= self.cfg.bg_warmup_frames:
            res.targets = []
            res.noise_floor = min(self.bg_profile) if self.bg_profile else 0.0
            res.peak_energy = max(profile)
            res.presence = False
            return res

        # 3. 背景减除检测
        targets: List[Target] = []
        for b in range(self.cfg.range_bin_min, min(n_bin, self.cfg.range_bin_max)):
            bg = self.bg_profile[b]
            if bg <= 0:
                continue
            if profile[b] > bg * self.cfg.detect_mult:
                angle = self._estimate_angle_at_bin(rx0, rx1, b)
                vel = self._estimate_velocity_at_bin(rx0, b)
                targets.append(Target(
                    range_bin=b,
                    velocity_bin=0,
                    distance_m=b * self.cfg.range_resolution_m,
                    velocity_mps=vel,
                    angle_deg=angle,
                    energy=profile[b] / bg,   # SNR：当前能量 / 背景能量
                ))

        res.targets = targets
        res.noise_floor = min(self.bg_profile) if self.bg_profile else 0.0
        res.peak_energy = max(profile)
        res.presence = len(targets) > 0
        return res

    def _estimate_angle_at_bin(self, rx0, rx1, b: int) -> float:
        """对目标 bin，用两 Rx 在 chirp 维平均的相位差估计到达角。"""
        if not self.cfg.angle_enable or len(rx1) < 2:
            return 0.0
        s0 = sum((complex(rx0[c][b]) for c in range(len(rx0)))) / len(rx0)
        s1 = sum((complex(rx1[c][b]) for c in range(len(rx1)))) / len(rx1)
        return self._estimate_angle(s0, s1)

    def _estimate_velocity_at_bin(self, rx0, b: int) -> float:
        """对目标 bin 的 chirp 序列做速度维 FFT，找多普勒峰（去 DC）。"""
        col = [complex(rx0[c][b]) for c in range(len(rx0))]
        if self.cfg.mti_enable:
            mean = sum(col) / len(col)
            col = [c - mean for c in col]
        col = col + [0j] * (self.n_vel - len(col))
        spec = fft(col)
        mag = [abs(v) for v in spec]
        # 跳过 vel 0（DC），找多普勒峰
        peak = max(range(1, self.n_vel), key=lambda i: mag[i])
        return self._vel_bin_to_mps(peak)

    def _estimate_angle(self, s0: complex, s1: complex) -> float:
        """由两个 Rx 的相位差估计到达角。

        Δφ = 2π·d·sinθ/λ，d = 6.25mm = λ/2 → Δφ = π·sinθ → θ = asin(Δφ/π)
        """
        if abs(s0) < 1e-9 or abs(s1) < 1e-9:
            return 0.0
        dphi = math.atan2((s1 * s0.conjugate()).imag, (s1 * s0.conjugate()).real)
        ratio = dphi / math.pi
        ratio = max(-1.0, min(1.0, ratio))
        return math.degrees(math.asin(ratio))

    def _vel_bin_to_mps(self, vb: int) -> float:
        # 速度 bin 0..n_vel/2 为正，其余为负（FFT 折叠）
        n = self.n_vel
        if vb <= n // 2:
            return vb * self.dv
        return (vb - n) * self.dv
