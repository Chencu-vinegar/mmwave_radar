# -*- coding: utf-8 -*-
"""纯 Python FFT（radix-2 Cooley-Tukey，支持 2 的幂次长度）。

信号处理量很小（64 点以内），标准库实现足够快，避免依赖 numpy。
"""
import cmath
import math
from typing import List, Sequence


def fft(x: Sequence[complex]) -> List[complex]:
    """前向 FFT（指数为 -i2πkn/N）。返回与输入等长的复数列表。"""
    n = len(x)
    if n == 0:
        return []
    a = list(x)
    # 位反转
    j = 0
    for i in range(1, n):
        bit = n >> 1
        while j & bit:
            j ^= bit
            bit >>= 1
        j ^= bit
        if i < j:
            a[i], a[j] = a[j], a[i]
    # 蝶形
    length = 2
    while length <= n:
        ang = -2.0 * math.pi / length
        wlen = complex(math.cos(ang), math.sin(ang))
        half = length >> 1
        for i in range(0, n, length):
            w = 1.0 + 0.0j
            for k in range(half):
                u = a[i + k]
                v = a[i + k + half] * w
                a[i + k] = u + v
                a[i + k + half] = u - v
                w *= wlen
        length <<= 1
    return a


def fft_magnitudes(x: Sequence[complex]) -> List[float]:
    """FFT 幅度谱。"""
    return [abs(v) for v in fft(x)]
