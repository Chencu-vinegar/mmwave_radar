# -*- coding: utf-8 -*-
"""毫米波雷达（加特兰 ICL1122 / DEV202H）处理程序配置。

所有参数集中在此，便于根据 SDK 文档或现场标定校正。
"""

from dataclasses import dataclass, field


@dataclass
class RadarConfig:
    # ---- 串口 ----
    port: str = "COM5"
    baudrate: int = 921600
    timeout: float = 0.5

    # ---- 雷达物理参数（来自 FILE_Radar_Config.ini）----
    freq_start_ghz: float = 24.015          # 起始频率
    freq_stop_ghz: float = 24.235           # 结束频率
    @property
    def freq_center_ghz(self) -> float:
        return (self.freq_start_ghz + self.freq_stop_ghz) / 2.0

    @property
    def bandwidth_hz(self) -> float:
        return (self.freq_stop_ghz - self.freq_start_ghz) * 1e9

    @property
    def wavelength_m(self) -> float:
        # 中心频率波长
        return 3e8 / (self.freq_center_ghz * 1e9)

    # ---- 1D FFT 输出 ----
    range_bins: int = 8                     # 1DFFTOutputCols = 8 个距离 bin
    # 距离分辨率：默认取 c/(2B) 物理值；ini 的 MTT_RangeResolution=125(约0.125m)
    # 是 MTT 算法内部量化，与 1D FFT bin 间距可能不同，此处可调。
    range_resolution_m: float = 3e8 / (2 * 220e6)   # ≈0.682 m/bin

    # ---- 天线 / 角度 ----
    rx_count: int = 2                       # RxChannelBit = 3 → 2 个 Rx
    tx_count: int = 1                       # TxChannelBit = 1
    antenna_spacing_m: float = 6.25e-3      # HorzAngleInfo = 6.250 (mm) = λ/2

    # ---- 帧结构 ----
    chirps_per_frame: int = 64              # ini 标称 64 chirp/帧
    # 实测每帧 64 条记录；flag=0/256 成对（Rx0/Rx1 分两条记录传输同一 chirp），
    # 故速度维有效 chirp 数 = 64 / 2 = 32。
    # 若 SDK 证实 flag 为 up/down chirp，请改为 64 并关闭角度估计。
    velocity_chirps: int = 32               # 每帧每 Rx 的 chirp 数（速度维长度）

    # ---- 信号处理 ----
    velocity_fft_size: int = 64             # 2D FFT 速度维尺寸（32 点补零到 64）
    min_energy: float = 25.0                # 目标最小能量（配合 ini ObjectMinEnergy=25）

    # ---- 检测（距离谱背景减除）----
    # 距离 bin 下限（忽略 0 的近距 DC/杂波区，见格式文档）
    range_bin_min: int = 1
    range_bin_max: int = 8
    # 背景建模：滑动平均距离谱，慢速适应增益漂移
    bg_alpha: float = 0.9                   # 背景更新系数（越接近 1 适应越慢）
    bg_warmup_frames: int = 8               # 背景预热帧数（只建背景不检测）
    detect_mult: float = 3.0                # 检测阈值：当前能量 > 背景 × 此倍数判为目标
    mti_enable: bool = True                 # 速度估计时去 DC 多普勒
    # 角度估计开关（若 flag 实际是 up/down 而非 Rx，需关闭）
    angle_enable: bool = True

    # ---- 输出 ----
    verbose: bool = True                    # 打印每帧检测结果
    raw_dump: bool = False                  # 打印原始 bin 幅度（调试）


@dataclass
class AppConfig:
    """运行方式配置。"""
    # 输入：串口 或 离线 .dat 文件
    source: str = "serial"                  # "serial" | "file"
    port: str = "COM5"
    file_path: str = ""
    replay_speedup: bool = True             # 文件回放是否按实时速率（False=最快）
    radar: RadarConfig = field(default_factory=RadarConfig)


# 默认导出
DEFAULT_CONFIG = AppConfig()
